<?php

declare(strict_types=1);

$page = t('pages.solutions', []);
?>
<section class="page-hero solutions-hero">
    <div class="container narrow">
        <p class="section-label"><?= e($page['hero']['label']) ?></p>
        <h1><?= e($page['hero']['title']) ?></h1>
        <p><?= e($page['hero']['body']) ?></p>
    </div>
</section>

<section class="section solutions-overview-section">
    <div class="container">
        <p class="section-label"><?= e($page['overview']['label']) ?></p>
        <div class="section-heading">
            <h2><?= e($page['overview']['title']) ?></h2>
            <p><?= e($page['overview']['body']) ?></p>
        </div>
        <div class="solution-card-grid">
            <?php foreach ($page['cards'] as $card): ?>
                <article class="solution-card">
                    <div class="solution-card-top">
                        <span class="solution-code"><?= e($card['code']) ?></span>
                        <span class="scenario-tag"><?= e($card['tag']) ?></span>
                    </div>
                    <h2><?= e($card['title']) ?></h2>
                    <p><?= e($card['text']) ?></p>
                    <ul class="solution-point-list">
                        <?php foreach ($card['points'] as $point): ?>
                            <li><?= e($point) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a class="text-link solution-link" href="<?= e(page_path($currentLocale, $card['page'])) ?>"><?= e($card['link']) ?></a>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section proof-section solutions-proof-section">
    <div class="container proof-grid">
        <div>
            <p class="section-label"><?= e($page['proof']['label']) ?></p>
            <h2><?= e($page['proof']['title']) ?></h2>
            <p><?= e($page['proof']['body']) ?></p>
        </div>
        <ul class="check-list">
            <?php foreach ($page['proof']['checks'] as $check): ?>
                <li><?= e($check) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<section class="final-cta compact">
    <div class="container">
        <h2><?= e($page['cta']['title']) ?></h2>
        <p><?= e($page['cta']['body']) ?></p>
        <div class="button-row center">
            <a class="button button-primary" href="<?= e(page_path($currentLocale, 'pilot')) ?>#contact"><?= e(t('site.cta.primary')) ?></a>
            <a class="button button-secondary" href="<?= e(page_path($currentLocale, 'platform')) ?>"><?= e(t('site.cta.explore_platform')) ?></a>
        </div>
    </div>
</section>
