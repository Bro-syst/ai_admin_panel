<?php

declare(strict_types=1);

$solution = t('pages.solution_details.' . $solutionKey, []);
?>
<section class="page-hero solution-detail-hero">
    <div class="container narrow">
        <p class="section-label"><?= e($solution['label']) ?></p>
        <h1><?= e($solution['title']) ?></h1>
        <p><?= e($solution['body']) ?></p>
        <div class="button-row">
            <a class="button button-primary" href="<?= e(page_path($currentLocale, 'pilot')) ?>#contact"><?= e(t('site.cta.primary')) ?></a>
            <a class="button button-secondary" href="<?= e(page_path($currentLocale, 'solutions')) ?>"><?= e(t('site.cta.view_solutions')) ?></a>
        </div>
    </div>
</section>

<section class="section solution-detail-section">
    <div class="container solution-detail-grid">
        <div>
            <p class="section-label"><?= e($solution['summary']['label']) ?></p>
            <h2><?= e($solution['summary']['title']) ?></h2>
            <p class="rich-text"><?= e($solution['summary']['body']) ?></p>
        </div>
        <div class="solution-fact-stack">
            <?php foreach ($solution['summary']['facts'] as $fact): ?>
                <article>
                    <span><?= e($fact['metric']) ?></span>
                    <h3><?= e($fact['title']) ?></h3>
                    <p><?= e($fact['text']) ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section surface solution-capabilities-section">
    <div class="container">
        <p class="section-label"><?= e($solution['capabilities']['label']) ?></p>
        <div class="section-heading">
            <h2><?= e($solution['capabilities']['title']) ?></h2>
            <p><?= e($solution['capabilities']['body']) ?></p>
        </div>
        <div class="solution-block-grid">
            <?php foreach ($solution['capabilities']['blocks'] as $block): ?>
                <article class="wide-panel">
                    <h2><?= e($block['title']) ?></h2>
                    <p><?= e($block['text']) ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section proof-section solution-agent-section">
    <div class="container proof-grid">
        <div>
            <p class="section-label"><?= e($solution['agents']['label']) ?></p>
            <h2><?= e($solution['agents']['title']) ?></h2>
            <p><?= e($solution['agents']['body']) ?></p>
        </div>
        <ul class="check-list">
            <?php foreach ($solution['agents']['checks'] as $check): ?>
                <li><?= e($check) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<section class="final-cta compact">
    <div class="container">
        <h2><?= e($solution['cta']['title']) ?></h2>
        <p><?= e($solution['cta']['body']) ?></p>
        <div class="button-row center">
            <a class="button button-primary" href="<?= e(page_path($currentLocale, 'pilot')) ?>#contact"><?= e(t('site.cta.primary')) ?></a>
            <a class="button button-secondary" href="<?= e(page_path($currentLocale, 'solutions')) ?>"><?= e(t('site.cta.view_solutions')) ?></a>
        </div>
    </div>
</section>
